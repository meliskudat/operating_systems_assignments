#include <algorithm>
#include <iostream>
#include <list>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <mutex>





using namespace std;


pthread_mutex_t mutex1 = PTHREAD_MUTEX_INITIALIZER ;

struct node
{

    int id ;
    int size;
    int index ;
    node* next ;
    node* previous ;

};



class HeapManager
{

      public:
        int initHeap(int size);
        int myMalloc(int ID, int size);
        int myFree(int ID, int index);
        void print();

    private:
     node* head ;

};




int HeapManager:: initHeap(int size) 
{
     head = new node ;
     head->size = size ;
     head ->next = NULL ;
     head -> previous = NULL ;
     head->index = 0 ;
     head -> id = -1 ; // means that it is free
     cout << "[" << head->id << "]" << "[" << head->size << "]" << "[" << head->index << "]" << endl ;

    return 1 ;
}



int HeapManager:: myMalloc(int ID, int size) 
{
    pthread_mutex_lock(&mutex1);
    node* ptr = head ;
   
    while( ptr != NULL)
    {
        if( ptr->size >= size && ptr -> id == -1 ) // means we find the node to be used
        {
            break;
        }
        ptr = ptr ->next ;
    }

    if( ptr == NULL)
    {
       cout << "Can not allocate, requested size " <<  size <<  "for thread " << ID << " is bigger than remaining size" << endl ;
       pthread_mutex_unlock(&mutex1);
        return -1 ;
    }

    else if( ptr ->size == size)
    {
        ptr -> id = ID ;
        cout << "Allocated for thread " << ID << endl;
        print() ;
        pthread_mutex_unlock(&mutex1);
        return ptr ->index ;
    
    }

    else
    {
        node* pint = new node ;
        pint ->id = ID ;
        pint -> size = size ;
        if( ptr != head)
        {
            ptr ->previous->next = pint ;
            pint ->next = ptr ;
            pint ->previous = ptr ->previous ;
            ptr -> previous = pint ;
            ptr -> size = ptr->size - size ;
            pint ->index = pint->previous->index + pint ->previous->size ;
            ptr ->index = pint->index + pint->size ;
            cout << "Allocated for thread " << ID << endl;
            print() ;
            pthread_mutex_unlock(&mutex1);
            return pint ->index ;

        }
        else if( ptr == head)
        {
            ptr -> previous = pint ;
            pint ->previous = NULL ;
            pint ->next = ptr ;
            pint -> next = ptr ;
            ptr -> size = ptr ->size - pint ->size ;
            pint -> index = 0 ;
            ptr ->index = pint ->size ;
            head = pint ;
            cout << "Allocated for thread " << ID << endl;
            print() ;
             pthread_mutex_unlock(&mutex1);
            return pint ->index ;
        }
    }
    pthread_mutex_unlock(&mutex1);
    return -1 ;
    
}

int HeapManager :: myFree(int ID, int index) // BU NODE EN BASTA YA DA EN SONDA ISE
{
  pthread_mutex_lock(&mutex1);
   node* pinter = head ;
   int counter = 0 ;
   while( pinter->id != ID || pinter->index != index) 
   {
     if( pinter ->next != NULL)
        pinter = pinter ->next; 
      else
      {
        counter = 1 ;
        break;
      }
   }

    if( counter == 1){ // meaning that no node exists with that index and ID
     pthread_mutex_unlock(&mutex1);
        return -1 ;
    }
    
    else{ // meaning that pinter points to node with that ID and index

        // three cases
        if( pinter ->previous != NULL && pinter ->next != NULL) // when left and right of the node not equal to null
        {

            if( pinter ->previous ->id == -1 && pinter ->next->id == -1) // meaning both left and the right are free
            {
                pinter -> size = pinter ->previous ->size + pinter ->size + pinter->next->size ;
                pinter ->index = pinter ->previous ->index ;
                pinter ->next = pinter ->next->next ;
                if( pinter ->next != NULL)
                pinter ->next ->previous = pinter ;
                
                pinter -> previous = pinter ->previous->previous ;
                if( pinter ->previous != NULL)
                    pinter ->previous ->next = pinter ;
                else
                  head = pinter ;

                pinter ->id = -1 ;
                cout << "Freed for thread " << ID << endl  ;
                print() ;
                 pthread_mutex_unlock(&mutex1);
                return 1 ;
                
            }

            else if( pinter ->previous->id == -1 && pinter->next->id != -1) // left is free
            {
                pinter ->size = pinter ->previous->size + pinter ->size ;
                pinter ->index = pinter ->previous->index ;
                pinter -> previous = pinter ->previous->previous ;
                if( pinter ->previous != NULL)
                {
                   pinter ->previous ->next = pinter ;
                }
                else
                  head = pinter ;
                
                pinter ->id = -1 ;
                cout << "Freed for thread " << ID << endl  ;
                print() ;
                 pthread_mutex_unlock(&mutex1);
                return 1 ;

            }

            else if( pinter ->previous ->id != -1 && pinter->next->id == -1 ) // right is free
            {
                pinter ->size = pinter ->next->size + pinter ->size ;
                pinter ->next = pinter ->next->next ;
                if( pinter ->next != NULL)
                pinter ->next ->previous = pinter ;
                
                pinter ->id = -1 ;
                cout << "Freed for thread " << ID << endl  ;
                print() ;
                 pthread_mutex_unlock(&mutex1);
                return 1 ;


            }

            else // left and right is busy
            {
                pinter -> id = -1 ;

                cout << "Freed for thread " << ID << endl  ;
                print() ;
                 pthread_mutex_unlock(&mutex1);
                return 1 ;
            }
        }


        else if( pinter -> previous == NULL && pinter ->next == NULL) // when left is null and right is null
        {
            pinter ->id = -1 ;
           
            cout << "Freed for thread " << ID << endl  ;
            print() ;
             pthread_mutex_unlock(&mutex1);
                return 1 ;
        }

        else if( pinter -> previous == NULL && pinter ->next != NULL) // when left is null and right is not null
        {
          if(pinter->next->id == -1) // merge
          {
                
                pinter -> size = pinter ->size + pinter ->next ->size ;
                pinter ->id = -1 ;

                pinter -> next = pinter ->next ->next ;
                if(pinter ->next != NULL)
                  pinter ->next ->previous = pinter ;

                
                cout << "Freed for thread " << ID << endl  ;
                print() ;
                 pthread_mutex_unlock(&mutex1);
                return 1 ;
          }

          else // not merge
          {
            pinter -> id = -1 ;
            cout << "Freed for thread " << ID << endl  ;
                print() ;
                 pthread_mutex_unlock(&mutex1);
                return 1 ;
          }
        }

        else if( pinter -> previous != NULL && pinter ->next == NULL) //when right is null and left is not null
        {

           if( pinter ->previous->id == -1) // merge
           {
            pinter -> size = pinter ->previous->size  + pinter ->size ;
            pinter -> index = 0 ;
            pinter -> id = -1 ;
            pinter ->previous = pinter ->previous->previous ;
            if(pinter ->previous != NULL)
            {
              pinter ->previous->next = pinter ;
            }
            else
              head = pinter ;

            cout << "Freed for thread " << ID << endl  ;
                print() ;
                 pthread_mutex_unlock(&mutex1);
               
           }
           else{ // not merge
            pinter ->id = -1 ;
            cout << "Freed for thread " << ID << endl  ;
                print() ;
                 pthread_mutex_unlock(&mutex1);
                return 1 ;
           }
            
        }



    }
    pthread_mutex_unlock(&mutex1);
    return -1 ;
    
}

void HeapManager:: print()
{
      
    node* pint = head ;
    while( pint ->next != NULL)
    {
        // id size index
        cout << "[" << pint->id << "]" << "[" << pint->size << "]" << "[" << pint->index << "]" << "---";
        pint = pint -> next ;
        
    }
    cout << "[" << pint->id << "]" << "[" << pint->size << "]" << "[" << pint->index << "]" << endl ;
}
