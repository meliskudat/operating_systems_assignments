#include <unistd.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>

struct Users
{
    char name[128];
    char lastname[128];
    char gender[128];
};

int count;

int isDirectory(const char *path)
{
    struct stat statbuf;
    if (stat(path, &statbuf) != 0)
        return 0;
    return S_ISDIR(statbuf.st_mode);
}

void listdir(const char *name, int indent, int array_size, struct Users users[count])
{

    int countX = 0;
    DIR *dir;
    struct dirent *entry;

    if (!(dir = opendir(name)))
        return;

    while ((entry = readdir(dir)) != NULL)
    {
        if (entry->d_type == DT_DIR) // bu da directory olanlarla
        {
            char path[1024];
            if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0)
                continue;
            snprintf(path, sizeof(path), "%s/%s", name, entry->d_name);
            // printf("%*s[%s]\n", indent, "", entry->d_name);
            listdir(path, indent + 2, array_size, users);
            //printf("\n") ;
        }

        else
        { // bu directory degil de txt olanlarla ugrasiyor

            // printf("%*s- %s\n", indent, "", entry->d_name);
            char *filename = entry->d_name;
            const size_t len = strlen(entry->d_name);
            char newname[1024];
            snprintf(newname, sizeof(newname), "%s/%s", name, entry->d_name);
            char *file_see = "./database.txt";

            if (strcmp(file_see, newname) == 0)
            {
            }

            else if (len > 4 && entry->d_name[len - 4] == '.' && entry->d_name[len - 3] == 't' && entry->d_name[len - 2] == 'x' && entry->d_name[len - 1] == 't') // just to open txt files
            {
                FILE *fp = fopen(newname, "r+");
                char word[20];
                if (!fp)
                {
                    printf("Can not open file \n");
                }

                while (!feof(fp))
                {

                    fscanf(fp, "%s", word);
                    int k;
                    for (k = 0; k < array_size; k++)
                    {
                        char *word_name = strdup(word);
                        if (strcmp(word_name, users[k].name) == 0)
                        {

                            char *realGen;
                            if (strcmp(users[k].gender, "m") == 0)
                                realGen = "Mr.";
                            else
                                realGen = "Ms.";
                            int offset1 = strlen(word_name) + 4;
                            fseek(fp, -offset1, SEEK_CUR);
                            fputs(realGen, fp);

                            fseek(fp, offset1 - 3, SEEK_CUR);

                            fseek(fp, 1, SEEK_CUR);

                            fputs(users[k].lastname, fp);
                            fseek(fp, -(strlen(users[k].lastname) + 1), SEEK_CUR);
                        }
                    }
                }
                fclose(fp);
            }
        }
    }
    closedir(dir);
}

int main(void)
{

    char *filenameX = "database.txt";
    FILE *fpt = fopen(filenameX, "r");
    if (!fpt)
    {
        printf("Can not open database file \n");
        return 1;
    }

    count = 0;
    char c;
    for (c = getc(fpt); c != EOF; c = getc(fpt))
    {
        if (c == '\n') // Increment count if this character is newline
            count = count + 1;
    }
    count += 1;
    //printf(" %d" , count);
    fseek(fpt, 0, SEEK_SET);

    struct Users users[count];

    char namex[128];
    char surnamex[128];
    char genderx[128];

    int x = 0;
    while (!feof(fpt))
    {
        fscanf(fpt, " %s %s %s ", genderx, namex, surnamex);
        strcpy(users[x].name, namex);
        strcpy(users[x].lastname, surnamex);
        strcpy(users[x].gender, genderx);
        //printf( " %s %s %s \n", &arr_gender[x], &arr_name[x], &arr_lastname[x]) ;
        x += 1;
    }
    //printf("%s\n" , &arr_name[0]) ;
    fclose(fpt);

    listdir(".", 0, count, users);

    return 0;
}

//
