

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <semaphore.h>



int first_team_fan_count ;
int second_team_fan_count ;

sem_t A_waiting ;
sem_t B_waiting ;
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER ;


int teamA_fan = 0 ;
int teamB_fan = 0 ;


void* teamA (void*pid)
{
	
	int boolean_for_A = 0; // meaning false
        pthread_mutex_lock(&lock);
        unsigned long tid;
   	tid = *((unsigned long *)pid);
    	printf("Thread ID: %ld, Team: A, I am looking for a car\n", tid);
        
        teamA_fan++;
        if (teamA_fan == 4) {
            
            sem_post(&A_waiting);
            sem_post(&A_waiting);
            sem_post(&A_waiting);
            teamA_fan -= 4;
            boolean_for_A = 1;
            pthread_mutex_lock(&lock);
           
        } 
        else if (teamB_fan == 2 && teamA_fan >= 2) {
          
            sem_post(&A_waiting);
            sem_post(&B_waiting);
            sem_post(&B_waiting);       
            boolean_for_A = 1;
            teamA_fan -= 2;
            teamB_fan -= 2;
            pthread_mutex_lock(&lock);
           
        } 
        else {	
            pthread_mutex_unlock(&lock);
            sem_wait(&A_waiting);
          
       
        }
       
    
        printf( "Thread ID: %ld, Team: A, I have found a spot in a car \n" , tid) ;
     

        
      
        if (boolean_for_A == 1 ) { 
  	      pthread_mutex_unlock(&lock);//
            printf( "Thread ID: %ld, Team: A, I am the captain and driving the car \n" , tid) ;
	
            pthread_mutex_unlock(&lock);
        }
        


      pthread_mutex_unlock(&lock);//

}


void* teamB (void*pid)
{

	
	int boolean_for_B = 0;
        pthread_mutex_lock(&lock);
        unsigned long tid;
        tid = *((unsigned long *)pid);
	printf( "Thread ID: %ld, Team: B, I am looking for a car \n" , tid) ;

        teamB_fan++;
        if (teamB_fan == 4) {
	    //pthread_mutex_unlock(&lock);
            sem_post(&B_waiting);
            sem_post(&B_waiting);
            sem_post(&B_waiting);
            teamB_fan -= 4;
            boolean_for_B = 1;
            pthread_mutex_lock(&lock) ;
       
        } 
        else if (teamA_fan == 2 && teamB_fan >= 2) {
             //pthread_mutex_unlock(&lock);
            sem_post(&B_waiting);
            sem_post(&A_waiting);
            sem_post(&A_waiting);
            boolean_for_B = 1;
            teamA_fan -= 2;
            teamB_fan -= 2;
            pthread_mutex_lock(&lock) ;
        } 
        else {
        
            pthread_mutex_unlock(&lock);
            sem_wait(&B_waiting);
            
  
        }
        
        printf( "Thread ID: %ld, Team: B, I have found a spot in a car \n" , tid) ;
   
   
      	
        if (boolean_for_B == 1 ) {
           pthread_mutex_unlock(&lock) ;
            printf( "Thread ID: %ld, Team: B, I am the captain and driving the car \n" , tid) ;

            pthread_mutex_unlock(&lock);
        }

	pthread_mutex_unlock(&lock);


}

int main( int argc, char* argv[])
{
	
	sem_init( &A_waiting , 0 ,0 ) ;
	sem_init( &B_waiting, 0 , 0) ;
	first_team_fan_count = atoi(argv[1]) ;
	second_team_fan_count = atoi(argv[2]) ;
	if( (first_team_fan_count + second_team_fan_count ) % 4 == 0 && (first_team_fan_count % 2 == 0 ) && ( second_team_fan_count % 2 == 0 ) )
	{
		int sum = first_team_fan_count + second_team_fan_count ;
		pthread_t forA[first_team_fan_count] ;
		pthread_t forB[second_team_fan_count] ;
		
		
		for( int i = 0 ; i < first_team_fan_count ; i++)
		{
			pthread_create(&forA[i], NULL, teamA, &forA[i]) ; 
		
		}
		
		for( int i = 0 ; i < second_team_fan_count ; i++)
		{
			pthread_create(&forB[i], NULL, teamB, &forB[i] ) ; 
		
		}
	 	
	

		for( int i = 0 ; i < first_team_fan_count ; i++)
		{
			pthread_join(forA[i], NULL ) ; 
		
		}
		
		for( int i = 0 ; i < second_team_fan_count ; i++)
		{
			pthread_join(forB[i], NULL ) ; 
		
		}
	
	
	}
	sem_destroy(&A_waiting) ;
	sem_destroy(&B_waiting) ;
	printf("The main terminates\n") ;

	return 0 ;

}
