#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>

// Melis's Program

int main( int argc, char* argv[] )
{
int piped_[2] ;
if(pipe(piped_) < 0)
  exit(1) ;

printf( "I'm SHELL process, with PID: %d - Main command is: man diff | grep -A 1 -e \"-y\"\n" , (int) getpid()); 
int fork1_ = fork() ;
if( fork1_ < 0 )
   exit(1);

if( fork1_ == 0 )
{
 // first child( man)
 
 printf( "I'm MAN process, with PID: %d - My command is: man diff\n " , (int) getpid()); 
 dup2(piped_[1] , STDOUT_FILENO) ;
 close( piped_[0] ) ;
 close(piped_[1] ) ; 
 
 char *command = "man" ;
 char *array_[3] ;
 array_[0] = "man" ;
 array_[1] = "diff" ;
 array_[2] = NULL ;
 execvp(command , array_) ; 
}


int fork2_ = fork() ;
if ( fork2_ < 0 )
{
   exit(1) ;
}

if( fork2_ == 0 )
{
 
  // second child(grep)

  printf( "I'm GREP process, with PID: %d - My command is: grep -A 1 -e \"-y\"\n" , (int) getpid()); 
  dup2( piped_[0], STDIN_FILENO) ;
  close(piped_[0]) ;
  close(piped_[1]) ;
  int fortext_ = open("output.txt" , O_WRONLY | O_CREAT , 0666) ;
  dup2( fortext_ ,1) ;
  close(fortext_ ) ;
  char *second_ = "grep" ;
  char *array_2[6] ;
  array_2[0] = "grep" ;
  array_2[1] = "-A";
  array_2[2] = "1" ; 
  array_2[3] = "-e" ;
  array_2[4] = "-y" ;
  array_2[5] = (char*)0;
  
  execvp(second_ , array_2) ; 
  // -A 1 is because I also want to take the next line after I find -y

}
else
{
 close( piped_[0] ) ;
 close( piped_[1] ) ;
 waitpid(fork1_, NULL , 0) ;
 waitpid(fork2_, NULL , 0 ) ;
 printf( "I'm SHELL process, with PID: %d - execution is completed, you can find the results in output.txt \n  " , (int) getpid()); 
}
}
