
#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include  <time.h>




pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER ;


int turn = 0 ;
int N; 
int go_out = 0 ;
char ** table ;

char result ;



void PrintMatrix()
{

	for(int a = 0 ; a < N ; a++)
	{
	   for( int b = 0 ; b < N ; b++)
	   {
	   	  char character = table[a][b] ;
        char begin_ = '[' ;
        char end_ = ']' ;
        printf("%c" , begin_) ;
        printf("%c" ,character) ;
        printf("%c" , end_) ;
         
	   }
	   
	printf( "\n" ) ;
  }
}
int isEqual () // to check if it is a tie or not
{
  int count = 0 ;
  int i , j ;
  int x = N * N ;

  for (i = 0 ; i < N ; i++)
  {
    for(j = 0 ; j < N ; j++)
    {
       if(table[i][j] != ' ' )
        count += 1 ;
    }
  }
  if(x==count)
    return 5;
  return -1;
}


int successAchievedforX()
{

    int count_a = 0 ;
     for( int i = 0 ; i < N ; i++) // from upper left to down right
     {
       if( table[i][i] == 'X' )
       {
       	count_a += 1 ;
       }
     
     }
     
    int count_b = 0 ;
    for( int i = 0 ; i < N ; i++) // from upper right to down left
    {
       if( table[N-1-i][i] == 'X' )
       {
       	count_b += 1 ;
       }
     
    }
    if( count_a == N || count_b == N)
    {
    	return 0 ;
    }
    
    
    int count_c  ;
    count_c = 0 ;
    for( int i = 0 ; i < N ; i++)  // row
    // from left to right
    {
       for( int a = 0 ; a < N ; a++) // column
       {
          if( table[i][a] == 'X' )
          {
            count_c += 1 ;
          }
       
       }
       if( count_c == N )
       {
         return 0 ;
       }
       
       else 
       {
          count_c = 0 ;
       }
    
    }
     
     
    int count_d = 0 ;
    for( int i = 0 ; i < N ; i++)  // row
    // from up to down
    {
       for( int a = 0 ; a < N ; a++) // column
       {
          if( table[a][i] == 'X' )
          {
            count_d += 1 ;
          }
       
       }
       if( count_d == N )
       {
         return 0 ;
       }
       
       else 
       {
          count_d = 0 ;
       }
     
     }
     if(isEqual()==5)
      return 2;
     
    return 1 ;
  
} 
 
int successAchievedforO()
{

    int count_a = 0 ;
     for( int i = 0 ; i < N ; i++) // from upper left to down right
     {
       if( table[i][i] == 'O')
       {
       	count_a += 1 ;
       }
     
     }
     
    int count_b = 0 ;
    for( int i = 0 ; i < N ; i++) // from upper right to down left
    {
       if( table[N-1-i][i] == 'O' )
       {
       	count_b += 1 ;
       }
     
    }
    
    if( count_a == N || count_b == N)
    {
    	return 0 ;
    }
    
    
    int count_c = 0 ;
    for( int i = 0 ; i < N ; i++)  // row
    // from left to right
     {
       for( int a = 0 ; a < N ; a++) // column
       {
          if( table[i][a] == 'O' )
          {
            count_c += 1 ;
          }
       
       }
       if( count_c == N )
       {
         return 0 ;
       }
       
       else 
       {
          count_c = 0 ;
       }
     
     }
     
     
    int count_d = 0 ;
    for( int i = 0 ; i < N ; i++)  // row
    // from up to down
     {
       for( int a = 0 ; a < N ; a++) // column
       {
          if( table[a][i] == 'O')
          {
            count_d += 1 ;
          }
       
       }
       if( count_d == N )
       {
         return 0 ;
       }
       
       else 
       {
          count_d = 0 ;
       }
     
     }

    
     if(isEqual()==5)
      return 2;

     return 1 ;

}





void* thread_func(void* arg)
{
 
  while(go_out == 0 ){
    while(turn != (long long)arg) // to be sure that o will not start
    {
      ;
    }



    pthread_mutex_lock(&lock) ;
    if ( (long long) arg == 0  && turn == 0 && go_out == 0)
    {
    		int x = rand() % N ;
    		int y = rand() % N ;
    		if( table[x][y] == ' ' )
    		{
    		  table[x][y] = 'X' ;
    		  turn = 1 ;
          printf("Player x played on: (%d,%d)\n",x,y);
    		  if( successAchievedforX() == 0 || successAchievedforX() == 2 ) // game is finished
    		  {
             go_out += 1 ;
            if( successAchievedforX() == 2)
              result = 'E' ;

            else
              result = 'X' ;

    		  	break ;
    		  }
    		}
    }
    
    if ( (long long) arg == 1 && turn == 1  && go_out == 0)
    {
    	  int x = rand() % N ;
    		int y = rand() % N ;
    		if( table[x][y] == ' ' )
    		{
    		  table[x][y] = 'O' ;
    		  turn = 0 ;
          printf("Player o played on: (%d,%d)\n",x,y);
    		   if( successAchievedforO() == 0 || successAchievedforO() == 2 ) // game is finished
    		  {
            go_out += 1 ;
            if( successAchievedforO() == 2)
              result = 'E' ;

            else
             result = 'O' ;
    
    		  	break ;
    		  }
    		}
    }
    pthread_mutex_unlock(&lock) ;
 }
    pthread_mutex_unlock(&lock) ;

}
int main( int argc, char* argv[])

{
	 
   N = atoi(argv[1]) ;
   srand(time(0));

   table = (char**) malloc(N *sizeof(char*)) ;
   for( int i = 0 ; i < N ; i++)
   { 
      table[i] = (char*) malloc( N * sizeof(char)) ;
   }
   for( int a = 0 ; a < N ; a ++)
   {
     for(int b = 0 ; b < N ; b++)
     {
       table[a][b] = ' ' ;
     }

   }

  
	// creating two threads
	pthread_t thread1 ; // for x
	pthread_t thread2 ; // for o 
	printf("Board Size: %dx%d\n" , N,N) ;
	pthread_create(&thread1 , NULL, thread_func, (void*) (long long) 0); // for x
	pthread_create(&thread2, NULL, thread_func, (void*) (long long) 1) ; // for o
	
  pthread_join(thread1, NULL) ;
  pthread_join(thread2, NULL ) ;
  
  printf("Game end\n") ;
  if( result == 'X')
    printf("Winner is X\n") ;

  else if( result == 'O')
    printf("Winner is O\n") ;

  else if ( result == 'E')
    printf("It is a tie\n") ;  
  
  PrintMatrix() ;
  
  return 0 ;

}


